# Pharos — GitHub Pages Website

This repository contains the public website for **Pharos**, the AI learning companion app.

## Pages

| Page | URL | Purpose |
|------|-----|---------|
| Landing | `/` | Marketing page (App Store Marketing URL) |
| Privacy Policy | `/privacy.html` | Required by Apple (Privacy Policy URL) |
| Support | `/support.html` | Required by Apple (Support URL) |

## Deploy to GitHub Pages

1. Create a new GitHub repository named `pharos` (or any name you prefer)
2. Upload these 3 files: `index.html`, `privacy.html`, `support.html`
3. Go to **Settings → Pages → Source → Deploy from branch → main**
4. Your site will be live at `https://YOUR-USERNAME.github.io/pharos/`

## App Store Connect URLs

Once deployed, paste these into App Store Connect:

- **Privacy Policy URL:** `https://YOUR-USERNAME.github.io/pharos/privacy.html`
- **Support URL:** `https://YOUR-USERNAME.github.io/pharos/support.html`
- **Marketing URL:** `https://YOUR-USERNAME.github.io/pharos/`

## Before Publishing

- [ ] Replace `support@pharosapp.com` with your real email in `support.html`
- [ ] Replace `privacy@pharosapp.com` with your real email in `privacy.html`
- [ ] Replace `bugs@pharosapp.com` with your real email in `support.html`
- [ ] Update the App Store download link in `index.html` (search for `href="#"`)
- [ ] Update the copyright year and company name in all footers if needed
